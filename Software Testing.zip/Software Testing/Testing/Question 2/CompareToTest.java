import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import java.math.BigInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CompareToTest {

    //Statement Coverage
    @Test
    @DisplayName("Statement Coverage - Test Case 1")
    public void testStatementCoverage1() {
        BigInteger a = new BigInteger("1", 10);
        BigInteger b = new BigInteger("2", 10);
        assertEquals(-1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Statement Coverage - Test Case 2")
    public void testStatementCoverage2() {
        BigInteger a = new BigInteger("2", 10);
        BigInteger b = new BigInteger("1", 10);
        assertEquals(1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Statement Coverage - Test Case 3")
    public void testStatementCoverage3() {
        BigInteger a = new BigInteger("1", 10);
        BigInteger b = new BigInteger("1", 10);
        assertEquals(0 , a.compareTo(b));
    }

    @Test
    @DisplayName("Statement Coverage - Test Case 4")
    public void testStatementCoverage4() {
        BigInteger a = new BigInteger("-10", 10);
        BigInteger b = new BigInteger("7000000000", 10);
        assertEquals(-1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Statement Coverage - Test Case 5")
    public void testStatementCoverage5() {
        BigInteger a = new BigInteger("10", 10);
        BigInteger b = new BigInteger("-7000000000", 10);
        assertEquals(1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Statement Coverage - Test Case 6")
    public void testStatementCoverage6() {
        BigInteger a = new BigInteger("10", 10);
        BigInteger b = new BigInteger("7000000000", 10);
        assertEquals(-1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Statement Coverage - Test Case 7")
    public void testStatementCoverage7() {
        BigInteger a = new BigInteger("7000000000", 10);
        BigInteger b = new BigInteger("10", 10);
        assertEquals(1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Statement Coverage - Test Case 8")
    public void testStatementCoverage8() {
        BigInteger a = new BigInteger("8000000000", 10);
        BigInteger b = new BigInteger("7000000000", 10);
        assertEquals(1 , a.compareTo(b));
    }
    ////////////////////////////
    //BRANCH DECISION COVERAGE//
    ////////////////////////////
    @Test
    @DisplayName("Branch Coverage - Test Case 1")
    public void testBranchCoverage1() {
        BigInteger a = new BigInteger("1", 10);
        BigInteger b = new BigInteger("2", 10);
        assertEquals(-1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Branch Coverage - Test Case 2")
    public void testBranchCoverage2() {
        BigInteger a = new BigInteger("2", 10);
        BigInteger b = new BigInteger("1", 10);
        assertEquals(1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Branch Coverage - Test Case 3")
    public void testBranchCoverage3() {
        BigInteger a = new BigInteger("1", 10);
        BigInteger b = new BigInteger("1", 10);
        assertEquals(0 , a.compareTo(b));
    }

    @Test
    @DisplayName("Branch Coverage - Test Case 4")
    public void testBranchCoverage4() {
        BigInteger a = new BigInteger("-10", 10);
        BigInteger b = new BigInteger("7000000000", 10);
        assertEquals(-1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Branch Coverage - Test Case 5")
    public void testBranchCoverage5() {
        BigInteger a = new BigInteger("10", 10);
        BigInteger b = new BigInteger("-7000000000", 10);
        assertEquals(1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Branch Coverage - Test Case 6")
    public void testBranchCoverage6() {
        BigInteger a = new BigInteger("10", 10);
        BigInteger b = new BigInteger("7000000000", 10);
        assertEquals(-1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Branch Coverage - Test Case 7")
    public void testBranchCoverage7() {
        BigInteger a = new BigInteger("7000000000", 10);
        BigInteger b = new BigInteger("10", 10);
        assertEquals(1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Branch Coverage - Test Case 8")
    public void testBranchCoverage8() {
        BigInteger a = new BigInteger("8000000000", 10);
        BigInteger b = new BigInteger("7000000000", 10);
        assertEquals(1 , a.compareTo(b));
    }

    ////////////////////////////
    //Condition Coverage Tests//
    ////////////////////////////

    @Test
    @DisplayName("Condition Coverage - Test Case 1")
    public void testConditionCoverage1() {
        BigInteger a = new BigInteger("1", 10);
        BigInteger b = new BigInteger("2", 10);
        assertEquals(-1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Condition Coverage - Test Case 2")
    public void testConditionCoverage2() {
        BigInteger a = new BigInteger("2", 10);
        BigInteger b = new BigInteger("1", 10);
        assertEquals(1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Condition Coverage - Test Case 3")
    public void testConditionCoverage3() {
        BigInteger a = new BigInteger("1", 10);
        BigInteger b = new BigInteger("1", 10);
        assertEquals(0 , a.compareTo(b));
    }

    @Test
    @DisplayName("Condition Coverage - Test Case 4")
    public void testConditionCoverage4() {
        BigInteger a = new BigInteger("-10", 10);
        BigInteger b = new BigInteger("7000000000", 10);
        assertEquals(-1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Condition Coverage - Test Case 5")
    public void testConditionCoverage5() {
        BigInteger a = new BigInteger("10", 10);
        BigInteger b = new BigInteger("-7000000000", 10);
        assertEquals(1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Condition Coverage - Test Case 6")
    public void testConditionCoverage6() {
        BigInteger a = new BigInteger("10", 10);
        BigInteger b = new BigInteger("7000000000", 10);
        assertEquals(-1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Condition Coverage - Test Case 7")
    public void testConditionCoverage7() {
        BigInteger a = new BigInteger("7000000000", 10);
        BigInteger b = new BigInteger("10", 10);
        assertEquals(1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Condition Coverage - Test Case 8")
    public void testConditionCoverage8() {
        BigInteger a = new BigInteger("8000000000", 10);
        BigInteger b = new BigInteger("7000000000", 10);
        assertEquals(1 , a.compareTo(b));
    }

    ///////////////////////////////////////
    //CONDITION / DECISION COVERAGE TESTS//
    ///////////////////////////////////////

    @Test
    @DisplayName("Condition/Decision Coverage - Test Case 1")
    public void testConditionDecisionCoverage1() {
        BigInteger a = new BigInteger("1", 10);
        BigInteger b = new BigInteger("2", 10);
        assertEquals(-1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Condition/Decision Coverage - Test Case 2")
    public void testConditionDecisionCoverage2() {
        BigInteger a = new BigInteger("2", 10);
        BigInteger b = new BigInteger("1", 10);
        assertEquals(1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Condition/Decision Coverage - Test Case 3")
    public void testConditionDecisionCoverage3() {
        BigInteger a = new BigInteger("1", 10);
        BigInteger b = new BigInteger("1", 10);
        assertEquals(0 , a.compareTo(b));
    }

    @Test
    @DisplayName("Condition/Decision Coverage - Test Case 4")
    public void testConditionDecisionCoverage4() {
        BigInteger a = new BigInteger("-10", 10);
        BigInteger b = new BigInteger("7000000000", 10);
        assertEquals(-1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Condition/Decision Coverage - Test Case 5")
    public void testConditionDecisionCoverage5() {
        BigInteger a = new BigInteger("10", 10);
        BigInteger b = new BigInteger("-7000000000", 10);
        assertEquals(1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Condition/Decision Coverage - Test Case 6")
    public void testConditionDecisionCoverage6() {
        BigInteger a = new BigInteger("10", 10);
        BigInteger b = new BigInteger("7000000000", 10);
        assertEquals(-1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Condition/Decision Coverage - Test Case 7")
    public void testConditionDecisionCoverage7() {
        BigInteger a = new BigInteger("7000000000", 10);
        BigInteger b = new BigInteger("10", 10);
        assertEquals(1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Condition/Decision Coverage - Test Case 8")
    public void testConditionDecisionCoverage8() {
        BigInteger a = new BigInteger("8000000000", 10);
        BigInteger b = new BigInteger("7000000000", 10);
        assertEquals(1 , a.compareTo(b));
    }

    ///////////////////////////////
    //MULTIPLE CONDITION COVERAGE//
    ///////////////////////////////

    @Test
    @DisplayName("Multiple Decision Coverage - Test Case 1")
    public void testMultipleDecisionCoverage1() {
        BigInteger a = new BigInteger("1", 10);
        BigInteger b = new BigInteger("2", 10);
        assertEquals(-1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Multiple Decision Coverage - Test Case 2")
    public void testMultipleDecisionCoverage2() {
        BigInteger a = new BigInteger("2", 10);
        BigInteger b = new BigInteger("1", 10);
        assertEquals(1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Multiple Decision Coverage - Test Case 3")
    public void testMultipleDecisionCoverage3() {
        BigInteger a = new BigInteger("1", 10);
        BigInteger b = new BigInteger("1", 10);
        assertEquals(0 , a.compareTo(b));
    }

    @Test
    @DisplayName("Multiple Decision Coverage - Test Case 4")
    public void testMultipleDecisionCoverage4() {
        BigInteger a = new BigInteger("-10", 10);
        BigInteger b = new BigInteger("7000000000", 10);
        assertEquals(-1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Multiple Decision Coverage - Test Case 5")
    public void testMultipleDecisionCoverage5() {
        BigInteger a = new BigInteger("10", 10);
        BigInteger b = new BigInteger("-7000000000", 10);
        assertEquals(1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Multiple Decision Coverage - Test Case 6")
    public void testMultipleDecisionCoverage6() {
        BigInteger a = new BigInteger("10", 10);
        BigInteger b = new BigInteger("7000000000", 10);
        assertEquals(-1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Multiple Decision Coverage - Test Case 7")
    public void testMultipleDecisionCoverage7() {
        BigInteger a = new BigInteger("7000000000", 10);
        BigInteger b = new BigInteger("10", 10);
        assertEquals(1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Multiple Decision Coverage - Test Case 8")
    public void testMultipleDecisionCoverage8() {
        BigInteger a = new BigInteger("8000000000", 10);
        BigInteger b = new BigInteger("7000000000", 10);
        assertEquals(1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Multiple Decision Coverage - Test Case 9")
    public void testMultipleDecisionCoverage9() {
        BigInteger a = new BigInteger("-7000000000", 10);
        BigInteger b = new BigInteger("-7000000000", 10);
        assertEquals(0 , a.compareTo(b));
    }

    @Test
    @DisplayName("Multiple Decision Coverage - Test Case 10")
    public void testMultipleDecisionCoverage10() {
        BigInteger a = new BigInteger("-10", 10);
        BigInteger b = new BigInteger("-7000000000", 10);
        assertEquals(1 , a.compareTo(b));
    }

    @Test
    @DisplayName("Multiple Decision Coverage - Test Case 11")
    public void testMultipleDecisionCoverage11() {
        BigInteger a = new BigInteger("-7000000000", 10);
        BigInteger b = new BigInteger("-10", 10);
        assertEquals(-1 , a.compareTo(b));
    }
}