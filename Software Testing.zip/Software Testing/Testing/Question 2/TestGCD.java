import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.math.BigInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestGCD {
    //Statement Coverage
    @Test
    @DisplayName("Statement Coverage - Test Case 1")
    public void testStatementCoverage1() {
        BigInteger x = new BigInteger("0");
        BigInteger y = new BigInteger("0");
        assertEquals(new BigInteger("0"), x.gcd(y));
    }

    @Test
    @DisplayName("Statement Coverage - Test Case 2")
    public void testStatementCoverage2() {
        BigInteger x = new BigInteger("-1");
        BigInteger y = new BigInteger("-1");
        assertEquals(new BigInteger("1"), x.gcd(y));
    }

    @Test
    @DisplayName("Statement Coverage - Test Case 3")
    public void testStatementCoverage3() {
        BigInteger x = new BigInteger("-1");
        BigInteger y = new BigInteger("2147483648");
        assertEquals(new BigInteger("1"), x.gcd(y));
    }

    @Test
    @DisplayName("Statement Coverage - Test Case 4")
    public void testStatementCoverage4() {
        BigInteger x = new BigInteger("2147483648");
        BigInteger y = new BigInteger("0");
        assertEquals(new BigInteger("2147483648"), x.gcd(y));
    }

    @Test
    @DisplayName("Statement Coverage - Test Case 5")
    public void testStatementCoverage5() {
        BigInteger x = new BigInteger("2147483648");
        BigInteger y = new BigInteger("1");
        assertEquals(new BigInteger("1"), x.gcd(y));
    }

    //Branch Decision Coverage
    @Test
    @DisplayName("Branch Decision Coverage - Test Case 1")
    public void testBranchDecisionCoverage1() {
        BigInteger x = new BigInteger("0");
        BigInteger y = new BigInteger("0");
        assertEquals(new BigInteger("0"), x.gcd(y));
    }

    @Test
    @DisplayName("Branch Decision Coverage - Test Case 2")
    public void testBranchDecisionCoverage2() {
        BigInteger x = new BigInteger("-1");
        BigInteger y = new BigInteger("-1");
        assertEquals(new BigInteger("1"), x.gcd(y));
    }

    @Test
    @DisplayName("Branch Decision Coverage - Test Case 3")
    public void testBranchDecisionCoverage3() {
        BigInteger x = new BigInteger("-1");
        BigInteger y = new BigInteger("2147483648");
        assertEquals(new BigInteger("1"), x.gcd(y));
    }

    @Test
    @DisplayName("Branch Decision Coverage - Test Case 4")
    public void testBranchDecisionCoverage4() {
        BigInteger x = new BigInteger("2147483648");
        BigInteger y = new BigInteger("0");
        assertEquals(new BigInteger("2147483648"), x.gcd(y));
    }

    @Test
    @DisplayName("Branch Decision Coverage - Test Case 5")
    public void testBranchDecisionCoverage5() {
        BigInteger x = new BigInteger("2147483648");
        BigInteger y = new BigInteger("1");
        assertEquals(new BigInteger("1"), x.gcd(y));
    }

    @Test
    @DisplayName("Branch Decision Coverage - Test Case 6")
    public void testBranchDecisionCoverage6() {
        BigInteger x = new BigInteger("1");
        BigInteger y = new BigInteger("1");
        assertEquals(new BigInteger("1"), x.gcd(y));
    }

    //Condition Coverage
    @Test
    @DisplayName("Condition Coverage - Test Case 1")
    public void testConditionCoverage1() {
        BigInteger x = new BigInteger("0");
        BigInteger y = new BigInteger("0");
        assertEquals(new BigInteger("0"), x.gcd(y));
    }

    @Test
    @DisplayName("Condition Coverage - Test Case 2")
    public void testConditionCoverage2() {
        BigInteger x = new BigInteger("-1");
        BigInteger y = new BigInteger("-1");
        assertEquals(new BigInteger("1"), x.gcd(y));
    }

    @Test
    @DisplayName("Condition Coverage - Test Case 3")
    public void testConditionCoverage3() {
        BigInteger x = new BigInteger("-2147483648");
        BigInteger y = new BigInteger("-2147483648");
        assertEquals(new BigInteger("2147483648"), x.gcd(y));
    }

    @Test
    @DisplayName("Condition Coverage - Test Case 4")
    public void testConditionCoverage4() {
        BigInteger x = new BigInteger("3");
        BigInteger y = new BigInteger("2147483648");
        assertEquals(new BigInteger("1"), x.gcd(y));
    }

    @Test
    @DisplayName("Condition Coverage - Test Case 5")
    public void testConditionCoverage5() {
        BigInteger x = new BigInteger("2147483648");
        BigInteger y = new BigInteger("0");
        assertEquals(new BigInteger("2147483648"), x.gcd(y));
    }

    @Test
    @DisplayName("Condition Coverage - Test Case 6")
    public void testConditionCoverage6() {
        BigInteger x = new BigInteger("2147483648");
        BigInteger y = new BigInteger("1");
        assertEquals(new BigInteger("1"), x.gcd(y));
    }

    @Test
    @DisplayName("Condition Coverage - Test Case 7")
    public void testConditionCoverage7() {
        BigInteger x = new BigInteger("1");
        BigInteger y = new BigInteger("1");
        assertEquals(new BigInteger("1"), x.gcd(y));
    }

    //Condition/Decision Coverage
    @Test
    @DisplayName("Condition/Decision Coverage - Test Case 1")
    public void testConditionDecisionCoverage1() {
        BigInteger x = new BigInteger("0");
        BigInteger y = new BigInteger("0");
        assertEquals(new BigInteger("0"), x.gcd(y));
    }

    @Test
    @DisplayName("Condition/Decision Coverage - Test Case 2")
    public void testConditionDecisionCoverage2() {
        BigInteger x = new BigInteger("-1");
        BigInteger y = new BigInteger("-1");
        assertEquals(new BigInteger("1"), x.gcd(y));
    }

    @Test
    @DisplayName("Condition/Decision Coverage - Test Case 3")
    public void testConditionDecisionCoverage3() {
        BigInteger x = new BigInteger("-2147483648");
        BigInteger y = new BigInteger("-2147483648");
        assertEquals(new BigInteger("2147483648"), x.gcd(y));
    }

    @Test
    @DisplayName("Condition/Decision Coverage - Test Case 4")
    public void testConditionDecisionCoverage4() {
        BigInteger x = new BigInteger("3");
        BigInteger y = new BigInteger("2147483648");
        assertEquals(new BigInteger("1"), x.gcd(y));
    }

    @Test
    @DisplayName("Condition/Decision Coverage - Test Case 5")
    public void testConditionDecisionCoverage5() {
        BigInteger x = new BigInteger("2147483648");
        BigInteger y = new BigInteger("0");
        assertEquals(new BigInteger("2147483648"), x.gcd(y));
    }

    @Test
    @DisplayName("Condition/Decision Coverage - Test Case 6")
    public void testConditionDecisionCoverage6() {
        BigInteger x = new BigInteger("2147483648");
        BigInteger y = new BigInteger("1");
        assertEquals(new BigInteger("1"), x.gcd(y));
    }

    @Test
    @DisplayName("Condition/Decision Coverage - Test Case 7")
    public void testConditionDecisionCoverage7() {
        BigInteger x = new BigInteger("1");
        BigInteger y = new BigInteger("1");
        assertEquals(new BigInteger("1"), x.gcd(y));
    }

    //Multiple Condition Coverage
    @Test
    @DisplayName("Multiple Condition Coverage - Test Case 1")
    public void testMultipleConditionCoverage1() {
        BigInteger x = new BigInteger("0");
        BigInteger y = new BigInteger("0");
        assertEquals(new BigInteger("0"), x.gcd(y));
    }

    @Test
    @DisplayName("Multiple Condition Coverage - Test Case 2")
    public void testMultipleConditionCoverage2() {
        BigInteger x = new BigInteger("-1");
        BigInteger y = new BigInteger("-1");
        assertEquals(new BigInteger("1"), x.gcd(y));
    }

    @Test
    @DisplayName("Multiple Condition Coverage - Test Case 3")
    public void testMultipleConditionCoverage3() {
        BigInteger x = new BigInteger("1");
        BigInteger y = new BigInteger("1");
        assertEquals(new BigInteger("1"), x.gcd(y));
    }

    @Test
    @DisplayName("Multiple Condition Coverage - Test Case 4")
    public void testMultipleConditionCoverage4() {
        BigInteger x = new BigInteger("1");
        BigInteger y = new BigInteger("-2147483648");
        assertEquals(new BigInteger("1"), x.gcd(y));
    }

    @Test
    @DisplayName("Multiple Condition Coverage - Test Case 5")
    public void testMultipleConditionCoverage5() {
        BigInteger x = new BigInteger("-2147483648");
        BigInteger y = new BigInteger("0");
        assertEquals(new BigInteger("2147483648"), x.gcd(y));
    }

    @Test
    @DisplayName("Multiple Condition Coverage - Test Case 6")
    public void testMultipleConditionCoverage6() {
        BigInteger x = new BigInteger("-2147483648");
        BigInteger y = new BigInteger("-2147483648");
        assertEquals(new BigInteger("2147483648"), x.gcd(y));
    }

    @Test
    @DisplayName("Multiple Condition Coverage - Test Case 7")
    public void testMultipleConditionCoverage7() {
        BigInteger x = new BigInteger("1");
        BigInteger y = new BigInteger("2147483648");
        assertEquals(new BigInteger("1"), x.gcd(y));
    }

    @Test
    @DisplayName("Multiple Condition Coverage - Test Case 8")
    public void testMultipleConditionCoverage8() {
        BigInteger x = new BigInteger("-2147483648");
        BigInteger y = new BigInteger("2147483648");
        assertEquals(new BigInteger("2147483648"), x.gcd(y));
    }

    @Test
    @DisplayName("Multiple Condition Coverage - Test Case 9")
    public void testMultipleConditionCoverage9() {
        BigInteger x = new BigInteger("2147483648");
        BigInteger y = new BigInteger("1");
        assertEquals(new BigInteger("1"), x.gcd(y));
    }
}
