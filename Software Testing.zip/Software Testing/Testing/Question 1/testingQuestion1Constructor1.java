import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.util.Arrays;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

class testingQuestion1Constructor1 {
    /*we have implemented a try and catch block so that if the tests reach the catch
    block the exception would be handled as this means the test has failed*/


    @Test 
    @DisplayName("Test case 1 when signum is -1 and Magnitude is {126,-127,-3,2}")
    public void blackBox1() {
        try {
            byte [] Magnitude = {126,-127,-3,2,};
            BigInteger signum = new BigInteger(-1, Magnitude);
            assertNotNull(signum);
        }catch(Exception e){
            assertFalse(true);
        }
    }
    @Test
    @DisplayName("Test case 2 when signum is 1 and Magnitude is {126,-127,-3,2}")
    public void blackBox2() {
        try {
            byte [] Magnitude = {126,-127,-3,2,};
            BigInteger signum = new BigInteger(1, Magnitude);
            assertNotNull(signum);
        }catch(Exception e){
            assertFalse(true);
        }
    }
    
    @Test
    @DisplayName("Test case 3 when signum is 0 and Magnitude is {0}")
    public void blackBox3() {
        try {
            byte [] Magnitude = {0};
            BigInteger signum = new BigInteger(0, Magnitude);
            assertNotNull(signum);
        }catch(Exception e){
            assertFalse(true);
        }

    }
    
    @Test
    @DisplayName("Test case 4 when signum is 0 and Magnitude is {126,-127,-3,2}")
    public void blackBox4() {
        try {
            byte [] Magnitude = {126,-127,-3,2,};
            BigInteger signum = new BigInteger(0, Magnitude);
            assertNotNull(signum);
        }catch(Exception e){
            assertFalse(true);
        }
    }

    
    @Test
    @DisplayName("Test case 5 when signum is -2 and Magnitude is {126,-127,-3,2}")
    public void blackBox5() {
        try {
            byte [] Magnitude = {126,-127,-3,2,};
            BigInteger signum = new BigInteger(-2, Magnitude);
            assertNotNull(signum);
        }catch(Exception e){
            assertFalse(true);
        }

    }
    @Test
    @DisplayName("Test case 6 when signum is 2 and Magnitude is {126,-127,-3,2}")
    public void blackBox6() {
        try {
            byte [] Magnitude = {126,-127,-3,2,};
            BigInteger signum = new BigInteger(2, Magnitude);
            assertNotNull(signum);
        }catch(Exception e){
            assertFalse(true);
        }
    }

}