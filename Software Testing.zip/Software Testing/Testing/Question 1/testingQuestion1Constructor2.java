import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.function.BooleanSupplier;
import static org.junit.jupiter.api.Assertions.assertEquals;

class testingQuestion1Constructor2 {
    /*we have implemented a try and catch block so that if the tests reach the catch
    block the exception would be handled as this means the test has failed*/

    @Test 
    @DisplayName("Test case 1 when radix is 10 and val is 0123456")
    public void blackBox1() {
        try {
            byte [] Magnitude = {127,-1,};
            BigInteger b = new BigInteger("0123456",10);
            assertNotNull(b);
        }catch(Exception e){
            assertFalse(true);
        }

    }
    
    @Test
    @DisplayName("Test case 2 when radix is 36 and val is 0123ADE")
    public void blackBox2() {
        try {
            byte [] Magnitude = {0};
            BigInteger b = new BigInteger("0123ADE",36);
            assertNotNull(b);
        }catch(Exception e){
            assertFalse(true);
        }

    }
    
    @Test
    @DisplayName("Test case 3 when radix is 10 and val is 0123ADE")
    public void blackBox3() {
        try {
            byte [] Magnitude = {127,-1};
            BigInteger b = new BigInteger("0123ADE",10);
            assertNotNull(b);
        }catch(Exception e){ assertFalse(true); }

    }
    @Test
    @DisplayName("Test case 4 when radix is 1 and val is 0123ADE")
    public void blackBox4() {
        try {
            byte [] Magnitude = {127,-1,};
            BigInteger b = new BigInteger("0123ADE",1);
            assertNotNull(b);
        }catch(Exception e){
            assertFalse(true);
        }
    }

    @Test
    @DisplayName("Test case 5 when radix is 37 and val is 0123ADE")
    public void blackBox5() {
        try {
            byte [] Magnitude = {127,-1};
            BigInteger b = new BigInteger("0123ADE",37);
            assertNotNull(b);
        }catch(Exception e){
            assertFalse(true);
        }
    }
}