import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import java.math.BigInteger;
import static org.junit.jupiter.api.Assertions.assertEquals;

class testingQuestion1Method3{
    BigInteger num1 = new BigInteger("1000",10);
    BigInteger num2 = new BigInteger("10000",10);
    BigInteger num3 = new BigInteger("1000",10);
    BigInteger num4 = new BigInteger("-1000",10);

    @Test 
    @DisplayName("Test case 1 when 1000 is being compared to 10000")
    public void blackBox1() {
        int test = num1.compareTo(num2);
        assertEquals(-1, test);
    }
    @Test
    @DisplayName("Test case 2 when 1000 is being compared to 1000")
    public void blackBox2() {
        int test = num1.compareTo(num3);
        assertEquals(0, test);
    }
    @Test
    @DisplayName("Test case 3 when 1000 is being compared to -1000")
    public void blackBox3() {
        int test = num1.compareTo(num4);
        assertEquals(1, test);
    }
}
